﻿using DBLayer;
using FinTrack.Models;
using FinTrack.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinTrack
{
    public partial class FrmPregledUnosa : Form
    {
        
        public FrmPregledUnosa()
        {
            InitializeComponent();
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void FrmPregledUnosa_Load(object sender, EventArgs e)
        {
            DB.SetConfiguration(
                    "PI2425_mbarnjak23_DB",
                    "PI2425_mbarnjak23_User",
                    "L(if;@Q@"
                );



            dgvUnosi.DataSource = UnosRepository.GetUnosi();
            dgvUnosi.Columns["Id"].Visible = false;
            dgvUnosi.Columns["KategorijaId"].Visible = false;

        }

        private void dgvUnosi_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnObrisi_Click(object sender, EventArgs e)
        {
            if (dgvUnosi.SelectedRows.Count > 0)
            {
                var unos = dgvUnosi.SelectedRows[0].DataBoundItem as Models.Unos; // dohvaća podatke iz odabrane ćelije
                                                                                  // DataBoundItem je originalni objekt iz liste koji je vezan uz taj red.
                if (unos != null) // Provjera da li je unos valjan
                {
                    var result = MessageBox.Show($"Jeste li sigurni da želite obrisati unos '{unos.Opis}'?", "Potvrda brisanja", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        UnosRepository.DeleteUnos(unos.Id);
                        dgvUnosi.DataSource = UnosRepository.GetUnosi(); // Refresh the data grid
                    }
                }
                else
                {
                    MessageBox.Show("Molimo odaberite unos za brisanje.", "Upozorenje", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnPretrazi_Click(object sender, EventArgs e)
        {
            string pojam = txtPretraga.Text.Trim();

            if (string.IsNullOrWhiteSpace(pojam))
            {
                dgvUnosi.DataSource = UnosRepository.GetUnosi(); // prikaz svih unosa ako ništa nije upisano
            }
            else
            {
                dgvUnosi.DataSource = UnosRepository.SearchUnosi(pojam); // prikaz samo onih koji sadrže pojam u opisu
            }
        }

        private void btnUredi_Click(object sender, EventArgs e)
        {
           if(dgvUnosi.SelectedRows.Count > 0)
            {
                var unos = dgvUnosi.SelectedRows[0].DataBoundItem as Models.Unos; // dohvaća podatke iz odabrane ćelije
                if (unos != null) // Provjera da li je unos valjan
                {
                    FrmUnos frmUnos = new FrmUnos(unos); // Prosljeđuje trenutni unos u formu za uređivanje
                    frmUnos.ShowDialog(); // Otvara formu kao modalnu
                    dgvUnosi.DataSource = UnosRepository.GetUnosi(); // Refresh the data grid
                }
            }
            else
            {
                MessageBox.Show("Molimo odaberite unos za uređivanje.", "Upozorenje", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void btnStatistika_Click(object sender, EventArgs e)
        {
            var frmStatistika = new FrmStatistika();
            frmStatistika.ShowDialog(); // Otvara formu za statistiku
        }
    }
}
